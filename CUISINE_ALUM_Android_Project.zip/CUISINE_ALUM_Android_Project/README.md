# CUISINE ALUM Android Project

Standalone Android Studio project wrapping the supplied kitchen calculator HTML prototype in a local WebView.

See `README_AR.md` for scope, limitations, and APK build steps.
